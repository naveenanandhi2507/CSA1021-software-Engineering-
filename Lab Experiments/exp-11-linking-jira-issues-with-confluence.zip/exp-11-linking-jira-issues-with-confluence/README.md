# Experiment 11: Linking Jira Issues with Confluence

| | |
|---|---|
| **Course** | CSA10 - Software Engineering Laboratory |
| **Institute** | Saveetha School of Engineering, SIMATS |
| **Tool** | Jira & Confluence |
| **CO** | CO2 |

## Aim
Linking Jira Issues with Confluence.

## Procedure
1. Create a Confluence space and a page (e.g. Project Requirements).
2. Insert the Jira issue macro to link issues.
3. Change an issue status in Jira and confirm the Confluence page updates.

## Source Code / Files

No source code - this experiment is done in the tool. Upload your exported work (screenshots/links) to this repo.

## Output
_Add your output here after running the experiment (terminal output, screenshot, or tool link)._

Output link: <!-- paste link -->

## Result
The experiment was completed successfully and the output was verified.
