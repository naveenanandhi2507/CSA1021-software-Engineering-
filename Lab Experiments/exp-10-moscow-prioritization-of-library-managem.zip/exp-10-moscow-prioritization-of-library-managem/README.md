# Experiment 10: MoSCoW Prioritization of Library Management System

| | |
|---|---|
| **Course** | CSA10 - Software Engineering Laboratory |
| **Institute** | Saveetha School of Engineering, SIMATS |
| **Tool** | Google Sheet/Excel |
| **CO** | CO2 |

## Aim
MoSCoW Prioritization of Library Management System.

## Procedure
1. Open `moscow_library.csv` in Excel or Google Sheets.
2. Classify each requirement as Must, Should, Could or Won't.
3. Add colour coding per category.

## Source Code / Files

**`moscow_library.csv`**
```text
ID,Requirement,MoSCoW,Reason
R1,Add/Edit/Delete books,Must,Core catalogue
R2,Member registration,Must,Needed to issue books
R3,Issue and return books,Must,Core function
R4,Search books by title/author,Must,Basic usability
R5,Fine calculation for late returns,Should,Important but manual workaround exists
R6,Email reminders,Should,Improves compliance
R7,Reserve a book online,Could,Nice to have
R8,Barcode scanning,Could,Efficiency gain
R9,Mobile app,Won't,Out of scope this release
R10,AI book recommendations,Won't,Future release
```

## Output
_Add your output here after running the experiment (terminal output, screenshot, or tool link)._

Output link: <!-- paste link -->

## Result
The experiment was completed successfully and the output was verified.
