#!/bin/bash
git clone https://github.com/YOUR_USER/team-project.git && cd team-project
git checkout -b feature-docs
# add README sections: Overview, Team, Setup, Usage
git add . && git commit -m 'Add README documentation'
git push -u origin feature-docs
# Open PR, teammate reviews, merge into main
