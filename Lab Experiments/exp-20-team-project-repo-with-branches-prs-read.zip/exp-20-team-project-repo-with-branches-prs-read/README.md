# Experiment 20: Team Project Repo with Branches, PRs, README

| | |
|---|---|
| **Course** | CSA10 - Software Engineering Laboratory |
| **Institute** | Saveetha School of Engineering, SIMATS |
| **Tool** | Git/GitHub |
| **CO** | CO5 |

## Aim
Team Project Repo with Branches, PRs, README.

## Procedure
1. Create the team repo and add collaborators.
2. Create a feature branch and write the README (Overview, Team, Setup, Usage).
3. Push and open a Pull Request, review and merge.

## Source Code / Files

**`commands.sh`**
```bash
#!/bin/bash
git clone https://github.com/YOUR_USER/team-project.git && cd team-project
git checkout -b feature-docs
# add README sections: Overview, Team, Setup, Usage
git add . && git commit -m 'Add README documentation'
git push -u origin feature-docs
# Open PR, teammate reviews, merge into main
```

## Output
_Add your output here after running the experiment (terminal output, screenshot, or tool link)._

Output link: <!-- paste link -->

## Result
The experiment was completed successfully and the output was verified.
