# Experiment 18: CI/CD with Jenkins for Containerized App

| | |
|---|---|
| **Course** | CSA10 - Software Engineering Laboratory |
| **Institute** | Saveetha School of Engineering, SIMATS |
| **Tool** | Docker/Jenkins |
| **CO** | CO4 |

## Aim
CI/CD with Jenkins for Containerized App.

## Procedure
1. Install Jenkins and add Docker Hub credentials with ID `dockerhub`.
2. Create a Pipeline job pointing to this repo's `Jenkinsfile`.
3. Click Build Now and view stage results.

## Source Code / Files

**`Dockerfile`**
```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
EXPOSE 5000
CMD ["python", "app.py"]
```

**`Jenkinsfile`**
```text
pipeline {
  agent any
  environment { IMAGE = "YOUR_DOCKERHUB_USERNAME/flask-api" }
  stages {
    stage('Checkout') { steps { checkout scm } }
    stage('Build Image') { steps { sh 'docker build -t $IMAGE:$BUILD_NUMBER .' } }
    stage('Test') { steps { sh 'docker run --rm $IMAGE:$BUILD_NUMBER python -c "import app; print(\'ok\')"' } }
    stage('Push') {
      steps {
        withCredentials([usernamePassword(credentialsId: 'dockerhub', usernameVariable: 'U', passwordVariable: 'P')]) {
          sh 'echo $P | docker login -u $U --password-stdin && docker push $IMAGE:$BUILD_NUMBER'
        }
      }
    }
  }
}
```

**`app.py`**
```python
from flask import Flask, jsonify
app = Flask(__name__)

@app.route("/")
def home():
    return jsonify(message="Hello from Flask in Docker/Kubernetes")

@app.route("/health")
def health():
    return jsonify(status="ok")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
```

**`requirements.txt`**
```text
flask==3.0.3
```

## Output
_Add your output here after running the experiment (terminal output, screenshot, or tool link)._

Output link: <!-- paste link -->

## Result
The experiment was completed successfully and the output was verified.
