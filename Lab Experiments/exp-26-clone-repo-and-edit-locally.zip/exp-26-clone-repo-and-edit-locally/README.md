# Experiment 26: Clone Repo and Edit Locally

| | |
|---|---|
| **Course** | CSA10 - Software Engineering Laboratory |
| **Institute** | Saveetha School of Engineering, SIMATS |
| **Tool** | Git/GitHub |
| **CO** | CO3 |

## Aim
Clone Repo and Edit Locally.

## Procedure
1. Run `commands.sh` to clone and edit the repo locally.
2. Show `git status` and `git diff`.

## Source Code / Files

**`commands.sh`**
```bash
#!/bin/bash
git clone https://github.com/YOUR_USER/my-repo.git && cd my-repo
echo 'Edited locally' >> README.md
git status && git diff
```

## Output
_Add your output here after running the experiment (terminal output, screenshot, or tool link)._

Output link: <!-- paste link -->

## Result
The experiment was completed successfully and the output was verified.
