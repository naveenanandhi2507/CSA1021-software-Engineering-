#!/bin/bash
git clone https://github.com/YOUR_USER/my-repo.git && cd my-repo
echo 'Edited locally' >> README.md
git status && git diff
