# Experiment 19: Continuous Deployment with GitHub Actions

| | |
|---|---|
| **Course** | CSA10 - Software Engineering Laboratory |
| **Institute** | Saveetha School of Engineering, SIMATS |
| **Tool** | Docker |
| **CO** | CO5 |

## Aim
Continuous Deployment with GitHub Actions.

## Procedure
1. Add `DOCKERHUB_USERNAME` and `DOCKERHUB_TOKEN` repo secrets.
2. Push to `main` to trigger `.github/workflows/cd.yml`.
3. Check the Actions run and the image on Docker Hub.

## Source Code / Files

**`.github/workflows/cd.yml`**
```yaml
name: CD
on:
  push:
    branches: [main]
jobs:
  build-and-push:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: docker/login-action@v3
        with:
          username: ${{ secrets.DOCKERHUB_USERNAME }}
          password: ${{ secrets.DOCKERHUB_TOKEN }}
      - uses: docker/build-push-action@v6
        with:
          context: .
          push: true
          tags: ${{ secrets.DOCKERHUB_USERNAME }}/flask-api:latest
```

**`Dockerfile`**
```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
EXPOSE 5000
CMD ["python", "app.py"]
```

**`app.py`**
```python
from flask import Flask, jsonify
app = Flask(__name__)

@app.route("/")
def home():
    return jsonify(message="Hello from Flask in Docker/Kubernetes")

@app.route("/health")
def health():
    return jsonify(status="ok")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
```

**`requirements.txt`**
```text
flask==3.0.3
```

## Output
_Add your output here after running the experiment (terminal output, screenshot, or tool link)._

Output link: <!-- paste link -->

## Result
The experiment was completed successfully and the output was verified.
