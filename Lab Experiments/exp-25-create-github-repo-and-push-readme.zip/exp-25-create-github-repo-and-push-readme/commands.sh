#!/bin/bash
git init my-repo && cd my-repo
echo '# My Repo' > README.md
git add README.md && git commit -m 'Add README'
git branch -M main
git remote add origin https://github.com/YOUR_USER/my-repo.git
git push -u origin main
