# Experiment 25: Create GitHub Repo and Push README

| | |
|---|---|
| **Course** | CSA10 - Software Engineering Laboratory |
| **Institute** | Saveetha School of Engineering, SIMATS |
| **Tool** | Git/GitHub |
| **CO** | CO3 |

## Aim
Create GitHub Repo and Push README.

## Procedure
1. Create an empty repo on GitHub.
2. Run the commands in `commands.sh`.
3. Refresh GitHub to see README.md.

## Source Code / Files

**`commands.sh`**
```bash
#!/bin/bash
git init my-repo && cd my-repo
echo '# My Repo' > README.md
git add README.md && git commit -m 'Add README'
git branch -M main
git remote add origin https://github.com/YOUR_USER/my-repo.git
git push -u origin main
```

## Output
_Add your output here after running the experiment (terminal output, screenshot, or tool link)._

Output link: <!-- paste link -->

## Result
The experiment was completed successfully and the output was verified.
