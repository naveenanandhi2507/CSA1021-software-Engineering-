kubectl apply -f app.yaml
kubectl get pods,svc
kubectl scale deployment backend --replicas=5
kubectl get pods
