# Experiment 23: Multi-Container App on Kubernetes with Scaling

| | |
|---|---|
| **Course** | CSA10 - Software Engineering Laboratory |
| **Institute** | Saveetha School of Engineering, SIMATS |
| **Tool** | Docker, Kubernetes |
| **CO** | CO3 |

## Aim
Multi-Container App on Kubernetes with Scaling.

## Procedure
1. Run `kubectl apply -f app.yaml`.
2. Check `kubectl get pods,svc`.
3. Scale: `kubectl scale deployment backend --replicas=5`.

## Source Code / Files

**`app.yaml`**
```yaml
apiVersion: v1
kind: Secret
metadata: { name: db-secret }
stringData: { POSTGRES_PASSWORD: example, POSTGRES_DB: appdb }
---
apiVersion: apps/v1
kind: Deployment
metadata: { name: database }
spec:
  replicas: 1
  selector: { matchLabels: { app: database } }
  template:
    metadata: { labels: { app: database } }
    spec:
      containers:
      - name: postgres
        image: postgres:16
        envFrom: [{ secretRef: { name: db-secret } }]
        ports: [{ containerPort: 5432 }]
---
apiVersion: v1
kind: Service
metadata: { name: database }
spec: { selector: { app: database }, ports: [{ port: 5432 }] }
---
apiVersion: apps/v1
kind: Deployment
metadata: { name: backend }
spec:
  replicas: 2
  selector: { matchLabels: { app: backend } }
  template:
    metadata: { labels: { app: backend } }
    spec:
      containers:
      - name: backend
        image: YOUR_DOCKERHUB_USERNAME/flask-api:1.0
        ports: [{ containerPort: 5000 }]
---
apiVersion: v1
kind: Service
metadata: { name: backend }
spec: { selector: { app: backend }, ports: [{ port: 5000 }] }
---
apiVersion: apps/v1
kind: Deployment
metadata: { name: frontend }
spec:
  replicas: 2
  selector: { matchLabels: { app: frontend } }
  template:
    metadata: { labels: { app: frontend } }
    spec:
      containers:
      - name: nginx
        image: nginx:alpine
        ports: [{ containerPort: 80 }]
---
apiVersion: v1
kind: Service
metadata: { name: frontend }
spec:
  type: NodePort
  selector: { app: frontend }
  ports: [{ port: 80 }]
```

**`scale.sh`**
```bash
kubectl apply -f app.yaml
kubectl get pods,svc
kubectl scale deployment backend --replicas=5
kubectl get pods
```

## Output
_Add your output here after running the experiment (terminal output, screenshot, or tool link)._

Output link: <!-- paste link -->

## Result
The experiment was completed successfully and the output was verified.
