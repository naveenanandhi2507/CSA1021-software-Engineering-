from flask import Flask, request, jsonify
app = Flask(__name__)
todos, next_id = [], 1

@app.get("/todos")
def list_todos(): return jsonify(todos)

@app.post("/todos")
def add():
    global next_id
    t = {"id": next_id, "title": request.json["title"], "done": False}
    todos.append(t); next_id += 1
    return jsonify(t), 201

@app.put("/todos/<int:i>")
def done(i):
    for t in todos:
        if t["id"] == i: t["done"] = True; return jsonify(t)
    return jsonify(error="not found"), 404

@app.delete("/todos/<int:i>")
def delete(i):
    global todos
    todos = [t for t in todos if t["id"] != i]
    return "", 204

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
