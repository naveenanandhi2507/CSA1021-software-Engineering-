# Experiment 21: Containerizing Flask To-Do App

| | |
|---|---|
| **Course** | CSA10 - Software Engineering Laboratory |
| **Institute** | Saveetha School of Engineering, SIMATS |
| **Tool** | Docker, Flask |
| **CO** | CO5 |

## Aim
Containerizing Flask To-Do App.

## Procedure
1. Build: `docker build -t todo-app .`
2. Run: `docker run -d -p 5000:5000 todo-app`
3. Test with curl: POST and GET `/todos`.

## Source Code / Files

**`Dockerfile`**
```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
EXPOSE 5000
CMD ["python", "app.py"]
```

**`app.py`**
```python
from flask import Flask, request, jsonify
app = Flask(__name__)
todos, next_id = [], 1

@app.get("/todos")
def list_todos(): return jsonify(todos)

@app.post("/todos")
def add():
    global next_id
    t = {"id": next_id, "title": request.json["title"], "done": False}
    todos.append(t); next_id += 1
    return jsonify(t), 201

@app.put("/todos/<int:i>")
def done(i):
    for t in todos:
        if t["id"] == i: t["done"] = True; return jsonify(t)
    return jsonify(error="not found"), 404

@app.delete("/todos/<int:i>")
def delete(i):
    global todos
    todos = [t for t in todos if t["id"] != i]
    return "", 204

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
```

**`requirements.txt`**
```text
flask==3.0.3
```

## Output
_Add your output here after running the experiment (terminal output, screenshot, or tool link)._

Output link: <!-- paste link -->

## Result
The experiment was completed successfully and the output was verified.
