# Experiment 16: Static Website with Docker and Nginx

| | |
|---|---|
| **Course** | CSA10 - Software Engineering Laboratory |
| **Institute** | Saveetha School of Engineering, SIMATS |
| **Tool** | Docker |
| **CO** | CO3 |

## Aim
Static Website with Docker and Nginx.

## Procedure
1. Write `index.html` and the `Dockerfile`.
2. Build: `docker build -t static-site .`
3. Run: `docker run -d -p 8080:80 static-site`
4. Open http://localhost:8080.

## Source Code / Files

**`Dockerfile`**
```dockerfile
FROM nginx:alpine
COPY index.html /usr/share/nginx/html/index.html
EXPOSE 80
```

**`index.html`**
```html
<!doctype html><html><head><title>Docker + Nginx</title></head><body><h1>Static site served by Nginx in Docker</h1></body></html>
```

## Output
_Add your output here after running the experiment (terminal output, screenshot, or tool link)._

Output link: <!-- paste link -->

## Result
The experiment was completed successfully and the output was verified.
