# Experiment 24: CI/CD for Flask with GitHub Actions + Cloud

| | |
|---|---|
| **Course** | CSA10 - Software Engineering Laboratory |
| **Institute** | Saveetha School of Engineering, SIMATS |
| **Tool** | GitHub Actions, Docker |
| **CO** | CO3 |

## Aim
CI/CD for Flask with GitHub Actions + Cloud.

## Procedure
1. Add Docker Hub and cloud deploy-hook secrets.
2. Push to `main` to run tests then deploy via `.github/workflows/ci-cd.yml`.
3. Check the Actions run.

## Source Code / Files

**`.github/workflows/ci-cd.yml`**
```yaml
name: CI-CD
on:
  push:
    branches: [main]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: "3.12" }
      - run: pip install -r requirements.txt && pytest -q
  deploy:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: docker/login-action@v3
        with:
          username: ${{ secrets.DOCKERHUB_USERNAME }}
          password: ${{ secrets.DOCKERHUB_TOKEN }}
      - uses: docker/build-push-action@v6
        with: { context: ., push: true, tags: "${{ secrets.DOCKERHUB_USERNAME }}/flask-app:latest" }
      # Cloud step (example: Render deploy hook; add RENDER_DEPLOY_HOOK secret)
      - run: curl -X POST "${{ secrets.RENDER_DEPLOY_HOOK }}"
```

**`Dockerfile`**
```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
EXPOSE 5000
CMD ["python", "app.py"]
```

**`app.py`**
```python
from flask import Flask, jsonify
app = Flask(__name__)

@app.route("/")
def home():
    return jsonify(message="Hello from Flask in Docker/Kubernetes")

@app.route("/health")
def health():
    return jsonify(status="ok")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
```

**`requirements.txt`**
```text
flask==3.0.3
pytest==8.3.2
```

**`test_app.py`**
```python
from app import app
def test_health():
    r = app.test_client().get("/health")
    assert r.status_code == 200 and r.json["status"] == "ok"
```

## Output
_Add your output here after running the experiment (terminal output, screenshot, or tool link)._

Output link: <!-- paste link -->

## Result
The experiment was completed successfully and the output was verified.
