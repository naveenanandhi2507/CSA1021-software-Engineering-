# Experiment 9: Scrum Project with Backlog and Sprint

| | |
|---|---|
| **Course** | CSA10 - Software Engineering Laboratory |
| **Institute** | Saveetha School of Engineering, SIMATS |
| **Tool** | Jira |
| **CO** | CO2 |

## Aim
Scrum Project with Backlog and Sprint.

## Procedure
1. Create a Scrum project in Jira.
2. Create an Epic and 8+ user stories in the Backlog.
3. Create Sprint 1 and move stories into it.
4. Start the sprint and open the Sprint board.
5. Show the burndown chart.

## Source Code / Files

No source code - this experiment is done in the tool. Upload your exported work (screenshots/links) to this repo.

## Output
_Add your output here after running the experiment (terminal output, screenshot, or tool link)._

Output link: <!-- paste link -->

## Result
The experiment was completed successfully and the output was verified.
