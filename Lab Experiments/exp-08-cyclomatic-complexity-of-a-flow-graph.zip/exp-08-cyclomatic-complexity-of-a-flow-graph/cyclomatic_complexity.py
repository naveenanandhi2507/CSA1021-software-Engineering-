# Flow graph of: read n; if n>0 { while n>0 { if n%2==0 even++ else odd++; n-- } } print
edges = [(1,2),(2,3),(2,9),(3,4),(4,5),(4,6),(5,7),(6,7),(7,8),(8,3),(8,9)]
nodes = {x for e in edges for x in e}
E, N, P = len(edges), len(nodes), 1
print(f"Nodes N = {N}, Edges E = {E}")
print(f"V(G) = E - N + 2P = {E} - {N} + 2 = {E-N+2*P}")
decisions = 3  # predicate nodes: 2, 4, 8
print(f"V(G) = predicates + 1 = {decisions} + 1 = {decisions+1}")
