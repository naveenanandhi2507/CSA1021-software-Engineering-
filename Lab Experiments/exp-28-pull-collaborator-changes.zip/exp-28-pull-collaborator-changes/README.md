# Experiment 28: Pull Collaborator Changes

| | |
|---|---|
| **Course** | CSA10 - Software Engineering Laboratory |
| **Institute** | Saveetha School of Engineering, SIMATS |
| **Tool** | Git/GitHub |
| **CO** | CO4 |

## Aim
Pull Collaborator Changes.

## Procedure
1. Have a collaborator push a change.
2. Run `git fetch` and `git pull`.
3. View the new commits.

## Source Code / Files

**`commands.sh`**
```bash
#!/bin/bash
# Collaborator pushes a change, then you run:
git fetch origin
git pull origin main
git log --oneline -5
```

## Output
_Add your output here after running the experiment (terminal output, screenshot, or tool link)._

Output link: <!-- paste link -->

## Result
The experiment was completed successfully and the output was verified.
