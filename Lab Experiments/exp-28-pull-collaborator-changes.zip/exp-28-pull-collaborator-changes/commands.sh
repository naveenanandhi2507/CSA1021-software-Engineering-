#!/bin/bash
# Collaborator pushes a change, then you run:
git fetch origin
git pull origin main
git log --oneline -5
