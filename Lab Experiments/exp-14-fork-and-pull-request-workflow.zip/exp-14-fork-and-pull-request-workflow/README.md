# Experiment 14: Fork-and-Pull-Request Workflow

| | |
|---|---|
| **Course** | CSA10 - Software Engineering Laboratory |
| **Institute** | Saveetha School of Engineering, SIMATS |
| **Tool** | Git/GitHub |
| **CO** | CO3 |

## Aim
Fork-and-Pull-Request Workflow.

## Procedure
1. Fork a public repository on GitHub.
2. Clone your fork and add the upstream remote.
3. Create a branch, make a change, commit and push.
4. Open a Pull Request to the original repository.

## Source Code / Files

**`commands.sh`**
```bash
#!/bin/bash
# Fork on GitHub UI first, then:
git clone https://github.com/YOUR_USER/REPO.git
cd REPO
git remote add upstream https://github.com/ORIGINAL_OWNER/REPO.git
git checkout -b fix-readme
echo 'change' >> README.md
git add . && git commit -m 'Update README'
git push origin fix-readme
# Open Pull Request on GitHub UI (compare & pull request)
```

## Output
_Add your output here after running the experiment (terminal output, screenshot, or tool link)._

Output link: <!-- paste link -->

## Result
The experiment was completed successfully and the output was verified.
