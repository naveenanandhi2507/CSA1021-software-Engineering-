#!/bin/bash
# Fork on GitHub UI first, then:
git clone https://github.com/YOUR_USER/REPO.git
cd REPO
git remote add upstream https://github.com/ORIGINAL_OWNER/REPO.git
git checkout -b fix-readme
echo 'change' >> README.md
git add . && git commit -m 'Update README'
git push origin fix-readme
# Open Pull Request on GitHub UI (compare & pull request)
