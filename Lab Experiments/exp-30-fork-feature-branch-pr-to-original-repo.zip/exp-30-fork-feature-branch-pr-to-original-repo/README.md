# Experiment 30: Fork, Feature Branch, PR to Original Repo

| | |
|---|---|
| **Course** | CSA10 - Software Engineering Laboratory |
| **Institute** | Saveetha School of Engineering, SIMATS |
| **Tool** | Git/GitHub |
| **CO** | CO4 |

## Aim
Fork, Feature Branch, PR to Original Repo.

## Procedure
1. Fork the original repo, clone and add upstream.
2. Create `feature-new`, commit and push.
3. Open a PR from your fork to the original repo.

## Source Code / Files

**`commands.sh`**
```bash
#!/bin/bash
# Click Fork on the original repo
git clone https://github.com/YOUR_USER/ORIGINAL_REPO.git && cd ORIGINAL_REPO
git remote add upstream https://github.com/ORIGINAL_OWNER/ORIGINAL_REPO.git
git checkout -b feature-new
echo 'feature' > feature.txt
git add . && git commit -m 'Add feature'
git push -u origin feature-new
# Open PR from YOUR_USER:feature-new to ORIGINAL_OWNER:main
```

## Output
_Add your output here after running the experiment (terminal output, screenshot, or tool link)._

Output link: <!-- paste link -->

## Result
The experiment was completed successfully and the output was verified.
