#!/bin/bash
# Click Fork on the original repo
git clone https://github.com/YOUR_USER/ORIGINAL_REPO.git && cd ORIGINAL_REPO
git remote add upstream https://github.com/ORIGINAL_OWNER/ORIGINAL_REPO.git
git checkout -b feature-new
echo 'feature' > feature.txt
git add . && git commit -m 'Add feature'
git push -u origin feature-new
# Open PR from YOUR_USER:feature-new to ORIGINAL_OWNER:main
