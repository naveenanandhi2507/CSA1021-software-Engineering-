# Experiment 13: MoSCoW and Kano for Online Learning Platform

| | |
|---|---|
| **Course** | CSA10 - Software Engineering Laboratory |
| **Institute** | Saveetha School of Engineering, SIMATS |
| **Tool** | Jira |
| **CO** | CO2 |

## Aim
MoSCoW and Kano for Online Learning Platform.

## Procedure
1. Create a Jira project for the Online Learning Platform.
2. Create issues for each requirement.
3. Add labels/fields for MoSCoW and Kano category using the CSV.
4. Show a filter/board grouped by priority.

## Source Code / Files

**`learning_platform_prioritization.csv`**
```text
Requirement,MoSCoW,Kano
Course catalogue and enrolment,Must,Must-be (basic)
Video lessons,Must,Must-be (basic)
Quizzes with auto-grading,Should,One-dimensional
Progress tracking,Should,One-dimensional
Certificates,Could,Attractive (delighter)
Gamification badges,Could,Attractive (delighter)
Live proctoring,Won't,Indifferent
```

## Output
_Add your output here after running the experiment (terminal output, screenshot, or tool link)._

Output link: <!-- paste link -->

## Result
The experiment was completed successfully and the output was verified.
