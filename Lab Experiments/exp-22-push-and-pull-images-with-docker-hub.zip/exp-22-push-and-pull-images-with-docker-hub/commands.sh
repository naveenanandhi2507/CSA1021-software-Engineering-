docker login
docker pull nginx:alpine
docker tag nginx:alpine YOUR_DOCKERHUB_USERNAME/my-nginx:v1
docker push YOUR_DOCKERHUB_USERNAME/my-nginx:v1
docker rmi YOUR_DOCKERHUB_USERNAME/my-nginx:v1
docker pull YOUR_DOCKERHUB_USERNAME/my-nginx:v1
docker run -d -p 8080:80 YOUR_DOCKERHUB_USERNAME/my-nginx:v1
curl http://localhost:8080
