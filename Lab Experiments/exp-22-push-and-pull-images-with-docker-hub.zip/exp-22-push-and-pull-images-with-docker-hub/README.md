# Experiment 22: Push and Pull Images with Docker Hub

| | |
|---|---|
| **Course** | CSA10 - Software Engineering Laboratory |
| **Institute** | Saveetha School of Engineering, SIMATS |
| **Tool** | Docker Hub, CLI |
| **CO** | CO3 |

## Aim
Push and Pull Images with Docker Hub.

## Procedure
1. Run the commands in `commands.sh` in order.
2. Verify the image on Docker Hub and that the pulled container serves the page.

## Source Code / Files

**`commands.sh`**
```bash
docker login
docker pull nginx:alpine
docker tag nginx:alpine YOUR_DOCKERHUB_USERNAME/my-nginx:v1
docker push YOUR_DOCKERHUB_USERNAME/my-nginx:v1
docker rmi YOUR_DOCKERHUB_USERNAME/my-nginx:v1
docker pull YOUR_DOCKERHUB_USERNAME/my-nginx:v1
docker run -d -p 8080:80 YOUR_DOCKERHUB_USERNAME/my-nginx:v1
curl http://localhost:8080
```

## Output
_Add your output here after running the experiment (terminal output, screenshot, or tool link)._

Output link: <!-- paste link -->

## Result
The experiment was completed successfully and the output was verified.
