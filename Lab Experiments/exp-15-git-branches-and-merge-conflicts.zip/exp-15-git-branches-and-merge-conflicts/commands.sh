#!/bin/bash
git init merge-demo && cd merge-demo
echo 'line1' > f.txt && git add . && git commit -m 'init'
git checkout -b branch-a && echo 'from A' > f.txt && git commit -am 'A edit'
git checkout main && git checkout -b branch-b && echo 'from B' > f.txt && git commit -am 'B edit'
git checkout main && git merge branch-a
git merge branch-b      # CONFLICT
git status
# edit f.txt, remove <<<<<<< ======= >>>>>>> markers
git add f.txt && git commit -m 'Resolve merge conflict'
git log --oneline --graph --all
