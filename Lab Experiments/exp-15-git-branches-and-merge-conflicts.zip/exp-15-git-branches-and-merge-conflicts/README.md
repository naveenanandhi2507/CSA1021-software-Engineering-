# Experiment 15: Git Branches and Merge Conflicts

| | |
|---|---|
| **Course** | CSA10 - Software Engineering Laboratory |
| **Institute** | Saveetha School of Engineering, SIMATS |
| **Tool** | Git/GitHub |
| **CO** | CO3 |

## Aim
Git Branches and Merge Conflicts.

## Procedure
1. Create a repo with an initial commit.
2. Create two branches editing the same line.
3. Merge both into main to trigger a conflict.
4. Resolve the conflict, commit and view the graph.

## Source Code / Files

**`commands.sh`**
```bash
#!/bin/bash
git init merge-demo && cd merge-demo
echo 'line1' > f.txt && git add . && git commit -m 'init'
git checkout -b branch-a && echo 'from A' > f.txt && git commit -am 'A edit'
git checkout main && git checkout -b branch-b && echo 'from B' > f.txt && git commit -am 'B edit'
git checkout main && git merge branch-a
git merge branch-b      # CONFLICT
git status
# edit f.txt, remove <<<<<<< ======= >>>>>>> markers
git add f.txt && git commit -m 'Resolve merge conflict'
git log --oneline --graph --all
```

## Output
_Add your output here after running the experiment (terminal output, screenshot, or tool link)._

Output link: <!-- paste link -->

## Result
The experiment was completed successfully and the output was verified.
