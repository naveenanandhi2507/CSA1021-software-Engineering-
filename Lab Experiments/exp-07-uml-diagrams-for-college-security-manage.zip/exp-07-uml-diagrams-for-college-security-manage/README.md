# Experiment 7: UML Diagrams for College Security Management System

| | |
|---|---|
| **Course** | CSA10 - Software Engineering Laboratory |
| **Institute** | Saveetha School of Engineering, SIMATS |
| **Tool** | Umbrello |
| **CO** | CO1 |

## Aim
UML Diagrams for College Security Management System.

## Procedure
1. Open Umbrello (or plantuml.com).
2. Create the Class, Use Case and Activity diagrams for the college security system.
3. Export each diagram as an image.

## Source Code / Files

**`activity.puml`**
```text
@startuml
start
:Person arrives at gate;
:Swipe ID card;
if (Card valid?) then (yes)
  :Open gate;
  :Record entry in log;
else (no)
  :Deny entry;
  :Alert guard;
endif
stop
@enduml
```

**`security_system.puml`**
```text
@startuml
class Person { +id; +name }
class Student
class Staff
class Visitor { +purpose }
class AccessCard { +cardId; +validTill; +isValid() }
class Gate { +location; +openGate() }
class AccessLog { +time; +status }
class SecurityGuard { +monitor(); +raiseAlert() }
Person <|-- Student
Person <|-- Staff
Person <|-- Visitor
Person "1" -- "1" AccessCard
AccessCard "1" -- "*" AccessLog
Gate "1" -- "*" AccessLog
SecurityGuard "1" -- "*" Gate
@enduml
```

**`usecase.puml`**
```text
@startuml
actor Student
actor Staff
actor Visitor
actor Guard
usecase "Swipe Card" as S
usecase "Register Visitor" as RV
usecase "View Access Logs" as L
usecase "Raise Alert" as A
Student --> S
Staff --> S
Visitor --> RV
Guard --> RV
Guard --> L
Guard --> A
@enduml
```

## Output
_Add your output here after running the experiment (terminal output, screenshot, or tool link)._

Output link: <!-- paste link -->

## Result
The experiment was completed successfully and the output was verified.
