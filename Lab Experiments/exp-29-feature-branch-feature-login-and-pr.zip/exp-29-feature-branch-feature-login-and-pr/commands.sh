#!/bin/bash
git checkout -b feature-login
echo 'login page' > login.html
git add . && git commit -m 'Add login page'
git push -u origin feature-login
# GitHub: Compare & pull request -> base: main <- compare: feature-login -> Create PR -> Merge
