# Experiment 29: Feature Branch (feature-login) and PR

| | |
|---|---|
| **Course** | CSA10 - Software Engineering Laboratory |
| **Institute** | Saveetha School of Engineering, SIMATS |
| **Tool** | Git/GitHub |
| **CO** | CO4 |

## Aim
Feature Branch (feature-login) and PR.

## Procedure
1. Create `feature-login`, add `login.html`, commit and push.
2. Open a Pull Request into main and merge it.

## Source Code / Files

**`commands.sh`**
```bash
#!/bin/bash
git checkout -b feature-login
echo 'login page' > login.html
git add . && git commit -m 'Add login page'
git push -u origin feature-login
# GitHub: Compare & pull request -> base: main <- compare: feature-login -> Create PR -> Merge
```

## Output
_Add your output here after running the experiment (terminal output, screenshot, or tool link)._

Output link: <!-- paste link -->

## Result
The experiment was completed successfully and the output was verified.
