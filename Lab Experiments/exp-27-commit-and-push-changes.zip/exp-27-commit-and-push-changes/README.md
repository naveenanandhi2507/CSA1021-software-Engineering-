# Experiment 27: Commit and Push Changes

| | |
|---|---|
| **Course** | CSA10 - Software Engineering Laboratory |
| **Institute** | Saveetha School of Engineering, SIMATS |
| **Tool** | Git/GitHub |
| **CO** | CO4 |

## Aim
Commit and Push Changes.

## Procedure
1. Edit a file, then run the commands in `commands.sh`.
2. Check the commit on GitHub.

## Source Code / Files

**`commands.sh`**
```bash
#!/bin/bash
echo 'new line' >> README.md
git add README.md
git commit -m 'Update README locally'
git push origin main
git log --oneline -3
```

## Output
_Add your output here after running the experiment (terminal output, screenshot, or tool link)._

Output link: <!-- paste link -->

## Result
The experiment was completed successfully and the output was verified.
