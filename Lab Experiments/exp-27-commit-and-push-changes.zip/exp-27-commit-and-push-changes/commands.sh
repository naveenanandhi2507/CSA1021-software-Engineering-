#!/bin/bash
echo 'new line' >> README.md
git add README.md
git commit -m 'Update README locally'
git push origin main
git log --oneline -3
