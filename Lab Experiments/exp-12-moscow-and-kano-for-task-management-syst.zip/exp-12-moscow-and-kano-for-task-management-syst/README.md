# Experiment 12: MoSCoW and Kano for Task Management System

| | |
|---|---|
| **Course** | CSA10 - Software Engineering Laboratory |
| **Institute** | Saveetha School of Engineering, SIMATS |
| **Tool** | Jira |
| **CO** | CO2 |

## Aim
MoSCoW and Kano for Task Management System.

## Procedure
1. Create a Jira project for the Task Management System.
2. Create issues for each requirement.
3. Add labels/fields for MoSCoW and Kano category using the CSV.
4. Show a filter/board grouped by priority.

## Source Code / Files

**`task_management_prioritization.csv`**
```text
Requirement,MoSCoW,Kano
Create/assign tasks,Must,Performance (expected)
Task status workflow,Must,Performance (expected)
Due-date reminders,Should,One-dimensional
Comments on tasks,Should,One-dimensional
Time tracking,Could,Attractive (delighter)
Dark mode,Could,Indifferent
Gantt chart,Won't,Attractive (later)
```

## Output
_Add your output here after running the experiment (terminal output, screenshot, or tool link)._

Output link: <!-- paste link -->

## Result
The experiment was completed successfully and the output was verified.
