# Experiment 17: Flask API: Docker, Docker Hub, Kubernetes

| | |
|---|---|
| **Course** | CSA10 - Software Engineering Laboratory |
| **Institute** | Saveetha School of Engineering, SIMATS |
| **Tool** | Docker & Kubernetes |
| **CO** | CO3 |

## Aim
Flask API: Docker, Docker Hub, Kubernetes.

## Procedure
1. Build the image: `docker build -t YOUR_DOCKERHUB_USERNAME/flask-api:1.0 .`
2. Push: `docker push YOUR_DOCKERHUB_USERNAME/flask-api:1.0`
3. Deploy: `kubectl apply -f k8s.yaml`
4. Check: `kubectl get pods,svc` and call the service URL.

## Source Code / Files

**`Dockerfile`**
```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
EXPOSE 5000
CMD ["python", "app.py"]
```

**`app.py`**
```python
from flask import Flask, jsonify
app = Flask(__name__)

@app.route("/")
def home():
    return jsonify(message="Hello from Flask in Docker/Kubernetes")

@app.route("/health")
def health():
    return jsonify(status="ok")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
```

**`k8s.yaml`**
```yaml
apiVersion: apps/v1
kind: Deployment
metadata: { name: flask-api }
spec:
  replicas: 2
  selector: { matchLabels: { app: flask-api } }
  template:
    metadata: { labels: { app: flask-api } }
    spec:
      containers:
      - name: flask-api
        image: YOUR_DOCKERHUB_USERNAME/flask-api:1.0
        ports: [{ containerPort: 5000 }]
---
apiVersion: v1
kind: Service
metadata: { name: flask-api-svc }
spec:
  type: NodePort
  selector: { app: flask-api }
  ports: [{ port: 80, targetPort: 5000 }]
```

**`requirements.txt`**
```text
flask==3.0.3
```

## Output
_Add your output here after running the experiment (terminal output, screenshot, or tool link)._

Output link: <!-- paste link -->

## Result
The experiment was completed successfully and the output was verified.
