# Experiment 6: UML Diagrams for Online Food Delivery System

| | |
|---|---|
| **Course** | CSA10 - Software Engineering Laboratory |
| **Institute** | Saveetha School of Engineering, SIMATS |
| **Tool** | Umbrello |
| **CO** | CO1 |

## Aim
UML Diagrams for Online Food Delivery System.

## Procedure
1. Open Umbrello (or paste the .puml files into plantuml.com).
2. Create the Class diagram, Use Case diagram and Activity diagram for the food delivery system.
3. Export each diagram as an image.

## Source Code / Files

**`activity.puml`**
```text
@startuml
start
:Customer browses menu;
:Place order;
:Make payment;
if (Payment successful?) then (yes)
  :Restaurant accepts order;
  :Prepare food;
  :Assign delivery agent;
  :Deliver to customer;
else (no)
  :Cancel order;
endif
stop
@enduml
```

**`food_delivery.puml`**
```text
@startuml
class Customer { +name; +address; +placeOrder(); +trackOrder() }
class Restaurant { +name; +menu; +acceptOrder() }
class Order { +id; +status; +total; +calculateTotal() }
class MenuItem { +name; +price }
class DeliveryAgent { +name; +vehicle; +deliver() }
class Payment { +amount; +method; +process() }
Customer "1" -- "*" Order
Restaurant "1" -- "*" MenuItem
Order "*" -- "*" MenuItem
Order "1" -- "1" Payment
Order "*" -- "1" DeliveryAgent
Restaurant "1" -- "*" Order
@enduml
```

**`usecase.puml`**
```text
@startuml
left to right direction
actor Customer
actor Restaurant
actor "Delivery Agent" as DA
rectangle "Food Delivery" {
 usecase "Browse Menu" as U1
 usecase "Place Order" as U2
 usecase "Make Payment" as U3
 usecase "Track Order" as U4
 usecase "Accept Order" as U5
 usecase "Deliver Order" as U6
}
Customer --> U1
Customer --> U2
Customer --> U3
Customer --> U4
Restaurant --> U5
DA --> U6
U2 .> U3 : <<include>>
@enduml
```

## Output
_Add your output here after running the experiment (terminal output, screenshot, or tool link)._

Output link: <!-- paste link -->

## Result
The experiment was completed successfully and the output was verified.
